export PATH=/90days/s4506266/softwares/FastQC-v0.11.7/:/90days/s4506266/softwares/FastUniq-1.1/source/:/30days/s4506266/softwares/anaconda3/bin:$PATH

/90days/s4506266/softwares/anaconda3/bin/readtrim --fq1 test.1.fq.gz --fq2 test.2.fq.gz --adap3 AGATCGGAAGAGCACACGTC --adap5 AGATCGGAAGAGCGTCGTGT --remove_headN --remove_dups --remove_adap --outdir /30days/s4506266/projects/7.zhengmin_comommax/1.Filter/0.remove_headN/test_readtrim/ --sample_name test
